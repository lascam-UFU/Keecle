/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package keecle;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

/**
 *
 * @author liliane_vale
 */
public class FindCallDiferent {
    String dir2;
    
    public FindCallDiferent(String dir){
    this.dir2=dir;
    } 

    public void getList(File f) {
//        System.out.println("entrei" + f);

        String aux;
        if (!f.isDirectory()) {
            // We keep only JAVA source file for display in this HowTo

            if (f.getName().endsWith(".txt")) {
                readClusterUtil(new File(f.getAbsolutePath()));

                //}
            }
        } else {
            File fList[] = f.listFiles();
            for (int j = 0; j < fList.length; j++) {
                getList(fList[j]);
            }
        }
//                          
    }

    public void readClusterUtil(File arquivo) {
        FileReader fr = null;
        String line = null;
        List<String> clusters = new ArrayList<>();
        clusters.remove(fr);
        String s[];
        String aux;
        String string;
        int cont = 0;
        try {
            fr = new FileReader(arquivo);
        } catch (FileNotFoundException ex) {
            Logger.getLogger(FindCallDiferent.class.getName()).log(Level.SEVERE, null, ex);
        }
        BufferedReader br = new BufferedReader(fr);
        try {
            line = br.readLine();
            aux = line.substring(line.indexOf(":") + 1, line.length());
            string = line.substring(0, line.indexOf(":"));
            clusters.add(line);

        } catch (IOException ex) {
            Logger.getLogger(FindCallDiferent.class.getName()).log(Level.SEVERE, null, ex);
        }
        while (line != null) {
            try {
                line = br.readLine(); //se tiver mais linhas, lê todas elas
                if (line != null) {
                    cont++;
                    aux = line.substring(line.indexOf(":") + 1, line.length());
                    string = line.substring(0, line.indexOf(":"));
                    clusters.add(line);
                }

            } catch (IOException ex) {
                Logger.getLogger(FindCallDiferent.class.getName()).log(Level.SEVERE, null, ex);
            }
        }//while
        try {
            br.close();

        } catch (IOException ex) {
            Logger.getLogger(FindCallDiferent.class.getName()).log(Level.SEVERE, null, ex);
        }
       // return clusters;
        deleteduplicate(clusters, arquivo.getName());
    }

    public void deleteduplicate(List<String> clusters2, String dir) {
        Set<String> seg = new HashSet<>();

        List<String> segments = new ArrayList<>();
        List<String> segments1 = new ArrayList<>();
        String id;
        String aux = "";
        String aux1 = "";
        String[] s;
        String string;
        String root;
        String[] format;
        // String feature;
        String auxfeature = "";
        for (int i = 0; i < clusters2.size(); i++) {
            string = clusters2.get(i).toString();
           // id = string.substring(0, string.indexOf(":"));
            //  feature = id.substring(0, id.lastIndexOf("-"));

            string = string.substring(string.indexOf(":") + 1, string.length());
            s = string.split("%");
            for (int j = 0; j < s.length - 1; j++) {
                root = s[j];
                format = root.split(",");

                aux = aux + format[0] + "," + format[1];

            }

            if (!segments.contains(aux)) {
                segments.add(aux);
                string = clusters2.get(i).toString();
                s = string.split("%");
                string = "";
                for (int m = 0; m < s.length; m++) {
                    string = s[m];

                    aux1 = aux1 + string + "%";
                }
                segments1.add(aux1);
                //segments1.add(aux1 + clusters2.get(i).toString().substring(clusters2.get(i).toString().lastIndexOf("%") + 1, clusters2.get(i).toString().length()));
                aux1 = "";
            }
            aux = "";

        }
        clusters2.clear();
        segments.clear();
        String id1;
        String string1;
        aux = "";
         aux1="";
         
                         write2(segments1, dir);

        for (int i = 0; i < segments1.size(); i++) {
            string = segments1.get(i).toString();
            id = string.substring(0, string.indexOf(":"));
            string = string.substring(string.indexOf(":") + 1, string.length());
            s = string.split("%");
            for (int j = 0; j < s.length - 1; j++) {
                root = s[j];
                format = root.split(",");

                aux = aux + format[0] + "," + format[1];

            }

            for (int j = 0; j < segments1.size(); j++) {
                string1 = segments1.get(j).toString();
                id1 = string1.substring(0, string1.indexOf(":"));
                s = string1.split("%");
            for (int k = 0; k < s.length - 1; k++) {
                root = s[k];
                format = root.split(",");

                aux1 = aux1 + format[0] + "," + format[1];

            }
                if (!id1.equals(id)) {
                    if(aux1.contains(aux)) {
                        segments.add(segments1.get(i));
                    }
                }
                aux1="";

            }
            aux="";
        }

        segments1.removeAll(segments);
        
    }

    public void write2(List cluster4, String dir1) {
              // File arquivo = new File("/Users/liliane_vale/Documents/doutorado/reconstrucaoArgoUml/clusters/inicializarargo-experimento1.txt"); //se não existir, lança exception  

        //  File arquivo = new File("/Users/liliane_vale/Documents/doutorado/estudoLucene/subtree-exerimento1.txt"); //se já existir, será sobreescrito  
        File arquivo = new File(this.dir2.substring(0, this.dir2.lastIndexOf("/"))+"/subtreeRI.txt"); //se já existir, será sobreescrito  

        // File arquivo = new File("/Users/liliane_vale/Documents/doutorado/estudodecasotomcat7/subtree-baseadoGr3.txt"); //se já existir, será sobreescrito  
        FileWriter fw = null;
        try {
            fw = new FileWriter(arquivo);

        } catch (IOException ex) {
            Logger.getLogger(FindCallDiferent.class
                    .getName()).log(Level.SEVERE, null, ex);
        }
        BufferedWriter bw = new BufferedWriter(fw);
        try {
            //    if(!cluster2.get(i).toString().equals("")){
            for (int j = 0; j < cluster4.size(); j++) {

                bw.write(cluster4.get(j).toString());
                bw.newLine();//}
            }

        } catch (IOException ex) {
            Logger.getLogger(FindCallDiferent.class
                    .getName()).log(Level.SEVERE, null, ex);
        }
        try {
            bw.flush();

        } catch (IOException ex) {
            Logger.getLogger(FindCallDiferent.class
                    .getName()).log(Level.SEVERE, null, ex);
        }
        try {
            bw.close();

        } catch (IOException ex) {
            Logger.getLogger(FindCallDiferent.class
                    .getName()).log(Level.SEVERE, null, ex);
        }

             JOptionPane.showMessageDialog(null, "Saven in:"+this.dir2.substring(0, this.dir2.lastIndexOf("/"))+"/subtreeRI.txt");
  }

 
}
