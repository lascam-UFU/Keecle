/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package keecle;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author liliane_vale
 */
public class CalcRecallPrecision {
    
    String tela="";
    int number;

    public void getList(File f1, File f2, int n) {
        this.number=n;
        String name1;
        String name2;
        String dir1;
        String dir2;

        name1 = f1.getName();
        name1 = name1.replace(".txt", "");
        dir1 = f1.getAbsolutePath();
  
        name2 = f2.getName();
        name2 = name2.replace(".txt", "");
        dir2 = f2.getAbsolutePath();
       // System.out.println("entrei" + dir2);
      
        readClusterUtil2(new File(f2.getAbsolutePath()), new File(f1.getAbsolutePath()));

       
    }

    public void readClusterUtil2(File arquivo, File arquivo2) {
         List<Integer> clusters2 = new ArrayList<>();

        List<String> clusters3 = new ArrayList<>();
      FileReader fr = null;
        String line = null;
        List<String> clusters = new ArrayList<>();
        String s[];
        String aux;
        String string;
///////////////le as subtrees
        try {
            fr = new FileReader(arquivo);
        } catch (FileNotFoundException ex) {
            Logger.getLogger(CalcRecallPrecision.class.getName()).log(Level.SEVERE, null, ex);
        }
        BufferedReader br = new BufferedReader(fr);
        try {
            line = br.readLine();

            clusters.add(line);

        } catch (IOException ex) {
            Logger.getLogger(CalcRecallPrecision.class.getName()).log(Level.SEVERE, null, ex);
        }
        while (line != null) {
            try {
                line = br.readLine(); //se tiver mais linhas, lê todas elas
                if (line != null) {

                    clusters.add(line);
                }

            } catch (IOException ex) {
                Logger.getLogger(CalcRecallPrecision.class.getName()).log(Level.SEVERE, null, ex);
            }
        }//while
        try {
            br.close();

        } catch (IOException ex) {
            Logger.getLogger(CalcRecallPrecision.class.getName()).log(Level.SEVERE, null, ex);
        }

////////////////////le as predicoes
        String tratamento;
        try {
            fr = new FileReader(arquivo2);
        } catch (FileNotFoundException ex) {
            Logger.getLogger(CalcRecallPrecision.class.getName()).log(Level.SEVERE, null, ex);
        }
        br = new BufferedReader(fr);
        try {
            line = br.readLine();

            if (line.contains(":yes")) {
                tratamento = line;
                tratamento = tratamento.substring(0, tratamento.indexOf("?"));

                tratamento = tratamento.replaceAll(" ", "");
                clusters2.add(Integer.parseInt(tratamento) - 1);
                // System.out.println("tratamento:"+tratamento+"tratamento:");

            }

        } catch (IOException ex) {
            Logger.getLogger(CalcRecallPrecision.class.getName()).log(Level.SEVERE, null, ex);
        }
        while (line != null) {
            try {
                line = br.readLine(); //se tiver mais linhas, lê todas elas
                if (line != null) {

                    if (line.contains(":yes")) {
                        tratamento = line;
                        tratamento = tratamento.substring(0, tratamento.indexOf("?"));
                        tratamento = tratamento.replaceAll(" ", "");
                        clusters2.add(Integer.parseInt(tratamento) - 1);

                    }
                }

            } catch (IOException ex) {
                Logger.getLogger(CalcRecallPrecision.class.getName()).log(Level.SEVERE, null, ex);
            }
        }//while
        try {
            br.close();

        } catch (IOException ex) {
            Logger.getLogger(CalcRecallPrecision.class.getName()).log(Level.SEVERE, null, ex);
        }

        ////////////
        String nivel;
        String tam;
        String cab;
        String aux1;
        double n = 0.0;
        double m = 0.0;
        double cl = 0.0;
        double pack = 0.0;
        double gr = 0.0;
        for (int j = 0; j < clusters2.size(); j++) {
            clusters3.add(clusters.get(clusters2.get(j)));
            aux1 = clusters.get(clusters2.get(j));
                                               // System.out.println(aux1);

            // System.out.println(aux1.substring(0, aux1.indexOf(","))+"..."+clusters2.get(j));
            tam = aux1;
            tam = tam.substring(0, tam.lastIndexOf("%"));

             tam = tam.substring(tam.lastIndexOf("%") + 1, tam.length());
            gr = gr + Double.parseDouble(tam);
            nivel = aux1;
            nivel = nivel.substring(0, nivel.indexOf("%"));
            nivel = nivel.substring(nivel.lastIndexOf(",") + 1, nivel.length());
            n = Double.parseDouble(nivel) + n;
            m = m + method(clusters.get(clusters2.get(j)));
            cl = cl + classe(clusters.get(clusters2.get(j)));
            pack = pack + pacote(clusters.get(clusters2.get(j)));

        }

        
                calcRank(clusters3);

        
    }

        public int classe1(List<String> input) {
        Set<String> numberC = new HashSet<>();
        String aux;
        String[] s;
        String[] string;

        for (int j = 0; j < input.size(); j++) {
            // System.out.println(input.get(j));
            string = input.get(j).split("%");
            aux = string[0];
            aux = aux.substring(aux.indexOf(":") + 1, aux.indexOf(","));

            numberC.add(aux);

            for (int i = 1; i < string.length - 1; i++) {
                aux = string[i];
                aux = aux.substring(0, aux.indexOf(","));
                // aux = aux.substring(aux.indexOf(".") + 1, aux.length());

                numberC.add(aux);
            }
        }
        return numberC.size();

    }

   
    public Integer method(String input) {
        Set<String> numberM = new HashSet<>();
        String aux;
        String[] s;
        String[] string;
        string = input.split("%");
        for (int i = 0; i < string.length - 1; i++) {
            aux = string[i];
            if (aux.contains("/")) {
                aux = aux.substring(0, aux.indexOf("/"));
            }
            aux = aux.substring(0, aux.lastIndexOf(","));
            numberM.add(aux);
        }

        return numberM.size();

    }

    public Integer classe(String input) {
        Set<String> numberC = new HashSet<>();
        String aux;
        String[] s;
        String[] string;
        string = input.split("%");
        aux = string[0];
        aux = aux.substring(aux.indexOf(":") + 1, aux.indexOf(","));

        numberC.add(aux);

        for (int i = 0; i < string.length - 1; i++) {
            aux = string[i];
            aux = aux.substring(0, aux.indexOf(","));
            // aux = aux.substring(aux.indexOf(".") + 1, aux.length());

            numberC.add(aux);
        }

        return numberC.size();

    }

    public List<Integer> Listpacote(List<String> subtrees1) {
        Set<String> numberP = new HashSet<>();
        List<Integer> numberP1 = new ArrayList<>();
        int maior;
        String aux;
        String[] s;
        String[] string;
        for (int j = 0; j < subtrees1.size(); j++) {
            string = subtrees1.get(j).split("%");
            for (int i = 0; i < string.length - 1; i++) {
                aux = string[i];
                aux = aux.substring(0, aux.indexOf(","));
                aux = aux.substring(0, aux.lastIndexOf("."));

                numberP.add(aux);
            }
            numberP1.add(numberP.size());
            numberP.clear();
        }
        Collections.sort(numberP1);
        //Collections.reverse(numberP1);
        return numberP1;

    }

    public List<Integer> Listmethod(List<String> subtrees1) {
        Set<String> numberM = new HashSet<>();
        List<Integer> numberM1 = new ArrayList<>();

        String aux;
        String[] s;
        String[] string;
        for (int j = 0; j < subtrees1.size(); j++) {
            string = subtrees1.get(j).split("%");
            //  System.out.println("imprime s[i]"+subtrees1.get(j));

            for (int i = 0; i < string.length - 1; i++) {
                aux = string[i];
                if (aux.contains("/")) {
                    aux = aux.substring(0, aux.indexOf("/"));
                }
                aux = aux.substring(0, aux.lastIndexOf(","));

                //  s = aux.split(",");
                numberM.add(aux);
            }
            numberM1.add(numberM.size());
            numberM.clear();
        }
        Collections.sort(numberM1);
        // Collections.reverse(numberM1);
        return numberM1;

    }

    public List<Integer> Listclasse(List<String> subtrees1) {
        Set<String> numberC = new HashSet<>();
        List<Integer> numberC1 = new ArrayList<>();

        String aux;
        String[] s;
        String[] string;
        for (int j = 0; j < subtrees1.size(); j++) {
            string = subtrees1.get(j).split("%");
            for (int i = 0; i < string.length - 1; i++) {
                aux = string[i];
                aux = aux.substring(0, aux.indexOf(","));
                // aux = aux.substring(aux.indexOf(".") + 1, aux.length());

                numberC.add(aux);
            }
            numberC1.add(numberC.size());
            numberC.clear();
        }
        Collections.sort(numberC1);
        // Collections.reverse(numberC1);

        return numberC1;

    }

    public Integer pacote(String input) {
        Set<String> numberP = new HashSet<>();
        List<Integer> numberC1 = new ArrayList<>();

        String aux;
        String[] s;
        String[] string;
        string = input.split("%");
        for (int i = 0; i < string.length - 1; i++) {
            aux = string[i];
            aux = aux.substring(0, aux.indexOf(","));
            aux = aux.substring(0, aux.lastIndexOf("."));

            numberP.add(aux);
        }
       // System.out.println("numero de pacote" + numberP.size());
        return numberP.size();

    }

    public List<Integer> ListNivel(List<String> subtrees1) {
        List<Integer> numberL1 = new ArrayList<>();

        String aux;
        String[] s;
        String[] level;
        String[] string;
        for (int j = 0; j < subtrees1.size(); j++) {
            string = subtrees1.get(j).split("%");
            aux = string[0];
            level = aux.split(",");
            // aux = aux.substring(aux.lastIndexOf(",") + 1, aux.length());
            numberL1.add(Integer.parseInt(level[2]));
        }
        Collections.sort(numberL1);
        return numberL1;

    }

    public Integer nivel(String subtrees1) {
        String aux;
        String[] s;
        String[] string;
        String[] level2;
        string = subtrees1.split("%");
        aux = string[0];
        //  aux = aux.substring(aux.lastIndexOf(",") + 1, aux.length());
        level2 = aux.split(",");
        return Integer.parseInt(level2[2]);

    }
    Set<String> classechave = new HashSet<>();

    public void calcRank(List<String> lista) {
        Set<String> keyclass = new HashSet<>();

        // lista.addAll(readClusterUtil2());
        int nivel2 = this.number;
        int currentqtde = 0;
        //  System.out.println("raizes no nivel: " + lista.size());
        int numeroclass = 0;
        int nivel = 0;
        int cont = 0;
        while (keyclass.size() < nivel2) {
            currentqtde = nivel2 - keyclass.size();
            keyclass.addAll(extractKeyClassesWhight(lista, currentqtde, nivel));
            nivel++;
        }
        Iterator<String> it = keyclass.iterator();
        while (it.hasNext()) {
            String string = it.next();

            System.out.println("classe chave >>" + string);
            this.tela=this.tela+"\n"+string;
        }
        this.classechave.addAll(keyclass);
    }

    public Set<String> extractKeyClassesWhight(List<String> lista1, int qtde, int nivel) {
        Set<String> keyclass1 = new HashSet<>();
        List<Integer> size = new ArrayList<>();
        List<String> subtrees = new ArrayList<>();
        List<BigDecimal> resultados = new ArrayList<>();
        List<String> ids = new ArrayList<>();
        String[] level;
        String tamanho;
        // int soma = 0;
        String[] s;
        int nivelcall;
        String buildsubtree = "";
        String classes = "";
        String call;
        int cont = 0;
        for (int j = 0; j < lista1.size(); j++) {
          tamanho = lista1.get(j).substring(0, lista1.get(j).lastIndexOf("%"));
           // tamanho = lista1.get(j);

            size.add(Integer.parseInt(tamanho.substring(tamanho.lastIndexOf("%") + 1, tamanho.length())));
        }
        Collections.sort(size);

        Collections.reverse(size);
      //  System.out.println(size.size() + "..raizes antes de extrair: " + size + "\n qual nivel: " + nivel);
        for (int j = 0; j < lista1.size(); j++) {
            call = lista1.get(j);
            s = call.split("%");
            level = s[0].split(",");
            nivelcall = Integer.parseInt(level[2]) + nivel;

            for (int i = 0; i < s.length - 1; i++) {
                level = s[i].split(",");
                if (Integer.parseInt(level[2]) == nivelcall) {
                    if (!buildsubtree.equals("")) {
                        subtrees.add(buildsubtree + cont);
                        buildsubtree = "";
                        cont = 0;
                    }
                    buildsubtree = buildsubtree + s[i] + "%";
                    cont++;
                }
                if (Integer.parseInt(level[2]) > nivelcall) {
                    buildsubtree = buildsubtree + s[i] + "%";
                    cont++;
                }
            }
            if (!buildsubtree.equals("")) {
                subtrees.add(buildsubtree + cont);
                buildsubtree = "";
                cont = 0;
            }
        }
        size.clear();
        for (int j = 0; j < subtrees.size(); j++) {
            size.add(Integer.parseInt(subtrees.get(j).substring(subtrees.get(j).lastIndexOf("%") + 1, subtrees.get(j).length())));
        }
        Collections.sort(size);

        //Collections.reverse(size);
      //  System.out.println(size.size() + "..raizes depois de extrair: " + size + "\n qual nivel: " + nivel);

        List<Integer> maiorNivel = new ArrayList<>();
        List<Integer> maiorMetodo = new ArrayList<>();
        List<Integer> maiorClasse = new ArrayList<>();
        List<Integer> maiorPacote = new ArrayList<>();
        List<String> cabecalhodaarvore = new ArrayList<>();

        maiorNivel.addAll(ListNivel(subtrees));
        maiorMetodo.addAll(Listmethod(subtrees));
        maiorClasse.addAll(Listclasse(subtrees));
        maiorPacote.addAll(Listpacote(subtrees));
        String id;
       

        double normalizacao = 0.0;
        for (int i = 0; i < subtrees.size(); i++) {
            call = subtrees.get(i);
            call = call.substring(call.lastIndexOf("%") + 1, call.length());

            if (size.size() != 1) {
                normalizacao = normalizacao + (1 * ((Integer.parseInt(call) - size.get(0)) / (size.get(size.size() - 1) - size.get(0))));
            }

            // System.out.println(new BigDecimal(normalizacao));
            if (maiorMetodo.size() != 1) {

                normalizacao = normalizacao + (0.24 * ((method(subtrees.get(i)) - maiorMetodo.get(0)) / (maiorMetodo.get(maiorMetodo.size() - 1) - maiorMetodo.get(0))));
                // System.out.println(new BigDecimal(normalizacao));
            }
            if (maiorClasse.size() != 1) {

               normalizacao = normalizacao + (0.2218 * ((classe(subtrees.get(i)) - maiorClasse.get(0)) / (maiorClasse.get(maiorClasse.size() - 1) - maiorClasse.get(0))));
                //  System.out.println(new BigDecimal(normalizacao));
            }
            if (maiorPacote.size() != 1) {

              normalizacao = normalizacao + (0.1507 * ((pacote(subtrees.get(i)) - maiorPacote.get(0)) / (maiorPacote.get(maiorPacote.size() - 1) - maiorPacote.get(0))));
                //  System.out.println(new BigDecimal(normalizacao));
            }
            if (maiorNivel.size() != 1) {

           normalizacao = normalizacao + (0.0228 * ((nivel(subtrees.get(i)) - maiorNivel.get(0)) / (maiorNivel.get(maiorNivel.size() - 1) - maiorNivel.get(0))));
                // System.out.println(new BigDecimal(normalizacao)+"\n\n");
            }
            id = subtrees.get(i);
            id = id.substring(0, id.indexOf(","));
            cabecalhodaarvore.add(id);
            if (id.contains(":")) {
                id = id.substring(id.indexOf(":") + 1, id.length());
            }
            
            ids.add(id + ";" + new BigDecimal(normalizacao));
//                        System.out.println(Integer.parseInt(call)+"size: " + id + (1 * ((Integer.parseInt(call) - size.get(0)) / (size.get(size.size() - 1) - size.get(0)))));
         double c=0.24 * ((method(subtrees.get(i)) - maiorMetodo.get(0)) / (maiorMetodo.get(maiorMetodo.size() - 1) - maiorMetodo.get(0)));
                        BigDecimal b = new BigDecimal(c);
//            System.out.println(method(subtrees.get(i))+"metodo: " + id + b.toString());
//            System.out.println(classe(subtrees.get(i))+"classe: " + id+ new BigDecimal((0.2218 * ((classe(subtrees.get(i)) - maiorClasse.get(0)) / (maiorClasse.get(maiorClasse.size() - 1) - maiorClasse.get(0))))));
//            System.out.println(pacote(subtrees.get(i))+"pacote: " + id + new BigDecimal((0.1507 * ((pacote(subtrees.get(i)) - maiorPacote.get(0)) / (maiorPacote.get(maiorPacote.size() - 1) - maiorPacote.get(0))))));
//            System.out.println(nivel(subtrees.get(i))+"nivel: " + id + new BigDecimal((0.0228 * ((nivel(subtrees.get(i)) - maiorNivel.get(0)) / (maiorNivel.get(maiorNivel.size() - 1) - maiorNivel.get(0))))));

            resultados.add(new BigDecimal(normalizacao));
            id = "";
            normalizacao = 0.0;
        }

        Collections.sort(resultados);
        Collections.reverse(resultados);
       // System.out.println(resultados);
        for (int j = 0; j < resultados.size(); j++) {
            for (int i = 0; i < ids.size(); i++) {
                call = ids.get(i);
                call = call.substring(call.indexOf(";") + 1, call.length());
                if (resultados.get(j).toString().equals(call)) {
                    if (keyclass1.size() < qtde) {
                        call = ids.get(i);
                        call = call.substring(0, call.indexOf(";"));
                        keyclass1.add(call);
//System.out.println("cabecalho da arvore: "+cabecalhodaarvore.get(i));

                       // System.out.println(ids.get(i));

                    }
                }

            }

        }

        return keyclass1;
    }

    
    

}
