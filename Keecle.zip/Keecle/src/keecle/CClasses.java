/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package keecle;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author liliane_vale
 */
public class CClasses {
        Set<String> clusters = new HashSet<>();


public void leiaclasses(List<String> aff){
    String [] s;
    String line;
    String aux;
    String string;
    for(int j=0; j<aff.size();j++){
        line=aff.get(j);
s=line.split("%");
            aux=s[0];
            aux=aux.substring(aux.indexOf(":")+1, aux.indexOf(","));
                        clusters.add(aux);
for(int i=1;i<s.length-1;i++){
    string=s[i];
   // System.out.println(s[i]);
string=string.substring(0, string.indexOf(","));
            clusters.add(string);}

}

}

   }
