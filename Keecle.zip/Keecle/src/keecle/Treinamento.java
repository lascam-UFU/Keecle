/*
 * Copyright (C) 2014 liliane_vale
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */
package keecle;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

/**
 *
 * @author liliane_vale
 */
public class Treinamento {
    String dir;
    public Treinamento(String string){
     this.dir=string;
    
    }

public void getList(File f) {
                List<String> dados1 = new ArrayList<>();
            File fList[] = f.listFiles();
            for (int j = 0; j < fList.length; j++) {
if (!fList[j].isDirectory()) {
            // We keep only JAVA source file for display in this HowTo

            if (fList[j].getName().endsWith(".txt")) {
//                if(!fList[j].getName().equals(".DS_Store")&fList[j].getName().contains("50-Tesoura.")){
//                if(fList[j].getName().contains("50-")){

                                dados1.addAll(readClusterUtil(fList[j].getAbsolutePath()));
                      //  System.out.println(fList[j].getName()+" entrei" + dados1.size());
            }
              // testar(dados1,fList[j].getName());
               // dados1.clear();
                //}}
            }
        
            treinar(dados1);
    }}

public void getList1(File f) {
                List<String> dados1 = new ArrayList<>();
            File fList[] = f.listFiles();
            for (int j = 0; j < fList.length; j++) {
if (!fList[j].isDirectory()) {
            // We keep only JAVA source file for display in this HowTo

            if (fList[j].getName().endsWith(".txt")) {
//                if(!fList[j].getName().equals(".DS_Store")&fList[j].getName().contains("50-Tesoura.")){
//                if(fList[j].getName().contains("50-")){

                                dados1.addAll(readClusterUtil(fList[j].getAbsolutePath()));
                      //  System.out.println(fList[j].getName()+" entrei" + dados1.size());

               testar(dados1,fList[j].getName());
                dados1.clear();
                //}}
            }}
        
           // treinar(dados1);
    }}

    public List<String> readClusterUtil(String file) {
        //File arquivo = new File("/Users/liliane_vale/Documents/doutorado/reconstrucaoArgoUml/clusters/inicializarargo.txt"); //se não existir, lança exception  
       // File arquivo = new File("/Users/liliane_vale/Documents/doutorado/artigo ICSE/subtree-reduced-javacc4.1.txt");

        File arquivo = new File(file);
        // File arquivo = new File("/Users/liliane_vale/Documents/doutorado/estudodecasotomcat7/subtree-fullyfeat.txt"); //se não existir, lança exception  
        FileReader fr = null;
        String line = null;
        List<String> clusters = new ArrayList<>();
        String s[];
        String aux;
        String string;

        try {
            fr = new FileReader(arquivo);
        } catch (FileNotFoundException ex) {
            Logger.getLogger(Treinamento.class.getName()).log(Level.SEVERE, null, ex);
        }
        BufferedReader br = new BufferedReader(fr);
        try {
            line = br.readLine();

            clusters.add(line);

        } catch (IOException ex) {
            Logger.getLogger(Treinamento.class.getName()).log(Level.SEVERE, null, ex);
        }
        while (line != null) {
            try {
                line = br.readLine(); //se tiver mais linhas, lê todas elas
                if (line != null) {
                    clusters.add(line);
                }

            } catch (IOException ex) {
                Logger.getLogger(Treinamento.class.getName()).log(Level.SEVERE, null, ex);
            }
        }//while
        try {
            br.close();

        } catch (IOException ex) {
            Logger.getLogger(Treinamento.class.getName()).log(Level.SEVERE, null, ex);
        }
        return clusters;

    }

    public Integer method(String input) {
        Set<String> numberM = new HashSet<>();
        String aux;
        String[] s;
        String[] string;
        string = input.split("%");
        for (int i = 0; i < string.length - 1; i++) {
            aux = string[i];
            if (aux.contains("%")) {
                aux = aux.substring(0, aux.indexOf("/"));
            }
            s = aux.split(",");
            numberM.add(s[1]);
        }

        return numberM.size();

    }

    public Integer classe(String input) {
        Set<String> numberC = new HashSet<>();
        String aux;
        String[] s;
        String[] string;
        string = input.split("%");
        for (int i = 0; i < string.length - 1; i++) {
            aux = string[i];
            aux = aux.substring(0, aux.indexOf(","));
            aux = aux.substring(aux.indexOf(".") + 1, aux.length());

            numberC.add(aux);
        }

        return numberC.size();

    }

    public Integer pacote(String input) {
        Set<String> numberP = new HashSet<>();
        String aux;
        String[] s;
        String[] string;
        string = input.split("%");
        for (int i = 0; i < string.length - 1; i++) {
            aux = string[i];
            aux = aux.substring(0, aux.indexOf(","));
            aux = aux.substring(0, aux.lastIndexOf("."));

            numberP.add(aux);
        }

        return numberP.size();

    }

    public void treinar(List<String> dados) {
      //  List<String> dados = new ArrayList<>();
        List<String> treino = new ArrayList<>();
        List<String> patterns = new ArrayList<>();
        List<String> treino1 = new ArrayList<>();
        List<String> notreino1 = new ArrayList<>();
        List<String> notreino = new ArrayList<>();
        int tem = 0;
       // dados.addAll(getList(new File("/Users/liliane_vale/Documents/doutorado/artigo ICSE/treino/")));
        //System.out.println(dados.size());
        String tree;
        String init;
        String cabecalho;
        String dado;
        String tamanho;
        int tam;
        String palavra;
        String nivel;
        String tpadrao = "";
        int metodo1;
        int classe1;
        int pacote;
        double media=0.0;
        //int instancia=0;
                for (int j = 0; j < dados.size(); j++) {
                                tree = dados.get(j);
                                tamanho = tree;
//                                                                   System.out.println(tamanho);
//
//            tamanho = tamanho.substring(0, tamanho.lastIndexOf("%"));
//                                                                               //System.out.println("tam"+tamanho);

            tamanho = tamanho.substring(tamanho.lastIndexOf("%") + 1, tamanho.length());

            tam = Integer.parseInt(tamanho);

            media=media+(double)tam;

                }
                media=media/dados.size();
                           // System.out.println("media: "+media);

        for (int j = 0; j < dados.size(); j++) {
            tree = dados.get(j);
            cabecalho=tree.substring(0, tree.indexOf("*")+1);
            pacote = pacote(tree);
            classe1 = classe(tree);
            metodo1 = method(tree);
            tamanho = tree;
           // tamanho = tamanho.substring(0, tamanho.lastIndexOf("%"));
            //System.out.println(tamanho);
            tamanho = tamanho.substring(tamanho.lastIndexOf("%") + 1, tamanho.length());
            tam = Integer.parseInt(tamanho);
            init = tree.substring(0, tree.indexOf("%"));
            nivel = init.substring(init.lastIndexOf(",") + 1, init.length());
              if ((double)tam >= media) {
                        palavra =nivel+","+ tamanho + "," + pacote + "," + classe1 + "," + metodo1+",yes";
                        treino.add(palavra);
                   }
                        // System.out.println("parte do if: "+j);

                        tem = 1;
                        
              if ((double)tam < media) {

                        palavra =nivel+","+ tamanho + "," + pacote + "," + classe1 + "," + metodo1+",no";
                        treino.add(palavra);
                        
          }
                                           
            tem = 0;
        }
        write2(treino,this.dir);
        //write3(notreino);

    }
 public void testar(List<String> dados, String arq) {
       // List<String> dados = new ArrayList<>();
        List<String> treino = new ArrayList<>();
        List<String> patterns = new ArrayList<>();
        List<String> treino1 = new ArrayList<>();
        List<String> notreino1 = new ArrayList<>();
        List<String> notreino = new ArrayList<>();
        int tem = 0;
       // dados.addAll(getList(new File("/Users/liliane_vale/Documents/doutorado/artigo ICSE/subtree-reduced-javacc4.1.txt")));
        String tree;
        String init;
        String cabecalho;
        String dado;
        String tamanho;
        int tam;
        String palavra;
        String nivel;
        String tpadrao = "";
        int metodo1;
        int classe1;
        int pacote;
        double media=0.0;
        //int instancia=0;
        for (int j = 0; j < dados.size(); j++) {
                                tree = dados.get(j);
                                tamanho = tree;
            tamanho = tamanho.substring(0, tamanho.lastIndexOf("%"));
            //System.out.println(tamanho);
            tamanho = tamanho.substring(tamanho.lastIndexOf("%") + 1, tamanho.length());
            tam = Integer.parseInt(tamanho);
            media=media+(double)tam;

                }
                media=media/dados.size();
        for (int j = 0; j < dados.size(); j++) {
            tree = dados.get(j);
            cabecalho=tree.substring(0, tree.indexOf("*")+1);
            pacote = pacote(tree);
            classe1 = classe(tree);
            metodo1 = method(tree);
            tamanho = tree;
            tamanho = tamanho.substring(0, tamanho.lastIndexOf("%"));
            //System.out.println(tamanho);
            tamanho = tamanho.substring(tamanho.lastIndexOf("%") + 1, tamanho.length());
            tam = Integer.parseInt(tamanho);
            init = tree.substring(0, tree.indexOf("%"));
           
            nivel = init.substring(init.lastIndexOf(",") + 1, init.length());
                        palavra =nivel+","+ tamanho + "," + pacote + "," + classe1 + "," + metodo1+",?";
                        treino.add(palavra);
                   
                        // System.out.println("parte do if: "+j);

                      
                                           
            tem = 0;
        }
        write2(treino, arq);
        //write3(notreino);

    }

    public void write2(List cluster4, String arq1) {
              // File arquivo = new File("/Users/liliane_vale/Documents/doutorado/reconstrucaoArgoUml/clusters/inicializarargo-experimento1.txt"); //se não existir, lança exception  

        //  File arquivo = new File("/Users/liliane_vale/Documents/doutorado/estudoLucene/subtree-exerimento1.txt"); //se já existir, será sobreescrito  
        File arquivo = new File(this.dir+"/train.arff"); //se já existir, será sobreescrito  

        // File arquivo = new File("/Users/liliane_vale/Documents/doutorado/estudodecasotomcat7/familias_experimento1.txt"); //se já existir, será sobreescrito  
        FileWriter fw = null;
        try {
            fw = new FileWriter(arquivo, true);

        } catch (IOException ex) {
            Logger.getLogger(Treinamento.class
                    .getName()).log(Level.SEVERE, null, ex);
        }
        BufferedWriter bw = new BufferedWriter(fw);
        try {
//            
//          //  @relation lucene
 
//

            //    if(!cluster2.get(i).toString().equals("")){
            for (int j = 0; j < cluster4.size(); j++) {

                bw.write(cluster4.get(j).toString());
                bw.newLine();//}
            }

        } catch (IOException ex) {
            Logger.getLogger(Treinamento.class
                    .getName()).log(Level.SEVERE, null, ex);
        }
        try {
            bw.flush();

        } catch (IOException ex) {
            Logger.getLogger(Treinamento.class
                    .getName()).log(Level.SEVERE, null, ex);
        }
        try {
            bw.close();

        } catch (IOException ex) {
            Logger.getLogger(Treinamento.class
                    .getName()).log(Level.SEVERE, null, ex);
        }

    }
public void write_head( String arq1) {
              // File arquivo = new File("/Users/liliane_vale/Documents/doutorado/reconstrucaoArgoUml/clusters/inicializarargo-experimento1.txt"); //se não existir, lança exception  

        //  File arquivo = new File("/Users/liliane_vale/Documents/doutorado/estudoLucene/subtree-exerimento1.txt"); //se já existir, será sobreescrito  
        File arquivo = new File(this.dir+"/train.arff"); //se já existir, será sobreescrito  

        // File arquivo = new File("/Users/liliane_vale/Documents/doutorado/estudodecasotomcat7/familias_experimento1.txt"); //se já existir, será sobreescrito  
        FileWriter fw = null;
        try {
            fw = new FileWriter(arquivo, true);

        } catch (IOException ex) {
            Logger.getLogger(Treinamento.class
                    .getName()).log(Level.SEVERE, null, ex);
        }
        BufferedWriter bw = new BufferedWriter(fw);
        try {
//            
//          //  @relation lucene
 bw.write("@relation name_software");
 bw.newLine();bw.newLine();
  bw.write("@attribute level 		NUMERIC");bw.newLine();
 bw.write("@attribute size 		NUMERIC");bw.newLine();
 bw.write("@attribute package 		NUMERIC");bw.newLine();
 bw.write("@attribute class 		NUMERIC");bw.newLine();
 bw.write("@attribute method 		NUMERIC");bw.newLine();
 bw.write("@attribute accept 		{yes, no}");
 bw.newLine();bw.newLine();
 bw.write("@data");bw.newLine();
//

            //    if(!cluster2.get(i).toString().equals("")){
           

        } catch (IOException ex) {
            Logger.getLogger(Treinamento.class
                    .getName()).log(Level.SEVERE, null, ex);
        }
        try {
            bw.flush();

        } catch (IOException ex) {
            Logger.getLogger(Treinamento.class
                    .getName()).log(Level.SEVERE, null, ex);
        }
        try {
            bw.close();

        } catch (IOException ex) {
            Logger.getLogger(Treinamento.class
                    .getName()).log(Level.SEVERE, null, ex);
        }

    }

    
    

}
